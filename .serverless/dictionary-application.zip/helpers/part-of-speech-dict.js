const posDict = {
  noun: 'n',
  pronoun: 'pron',
  verb: 'v',
  adjective: 'a',
  adverb: 'adv',
  preposition: 'prep',
  conjunction: 'conj',
  interjection: 'interj',
};
module.exports = posDict;
